public class ConstantFun
{

	public static void main (String[] args)
	{
		
		final double INTERESTRATE = 5.0; //Named Constant
		
		System.out.println(INTERESTRATE);
	
	}

}