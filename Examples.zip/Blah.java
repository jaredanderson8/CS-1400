import java.util.Scanner;

public class Blah
{

   public static void main (String[] args)
   {
      Scanner in = new Scanner (System.in);
      String variableName = "";
      char ch = ' ';
      boolean illegal = false;
      
      System.out.println("Enter a variable name");
      variableName = in.nextLine();
      
      ch = variableName.charAt(0);
      
      if (!Character.isLetter(ch))
      {
         illegal = true;
      }
      
      if (illegal)
      {
         System.out.println("Illegal");
      }
   
   }

}