import java.util.Scanner;
import java.util.Random;

public class CoinFlipFun
{

	public static void main (String[] args)
	{
		Scanner in = new Scanner (System.in);
		Random r = new Random ();
	
		int userPick = 0; //1 for Heads, 2 for Tails
		int flipResult = 0; //1 for Heads, 2 for Tails
		int numberOfFlips = 0;
		int numberOfWins = 0;
		String playAgain = ""; //Y or N
		
		//Play the game while the user continues to say Yes
		do
		{
			//Getting user selection
			System.out.println("Enter 1 for Heads, or 2 for Tails");
			userPick = in.nextInt();
			
			//Check for valid input
			while (userPick != 1 && userPick != 2)
			{
				System.out.println("Invalid input.  Try again");
				System.out.println("Enter 1 for Heads, or 2 for Tails");
				userPick = in.nextInt();
			}
			
			//Simulate coin flip and increase count of games
			flipResult = r.nextInt(2) + 1;
			numberOfFlips++;
			
			//Print which side was flipped
			if (flipResult == 1)
			{
				System.out.println("It was heads!");
			}
			if (flipResult == 2)
			{
				System.out.println("It was tails!");
			}
			
			//Check and print results
			if (userPick == flipResult)
			{
				System.out.println("You win!");
				numberOfWins++;
			}
			else
			{
				System.out.println("You lose!");
			}
			
			//Flush the buffer
			in.nextLine();
		
			//See if the user wants to continue
			System.out.println("Play again? Y or N?");
			playAgain = in.nextLine();
			
			//Check for valid input
			while (!playAgain.equalsIgnoreCase("Y") &&
				!playAgain.equalsIgnoreCase("N"))
			{
				System.out.println("Invalid input.  Try again.");
				System.out.println("Play again?  Y or N?");
				playAgain = in.nextLine();
			}
		
		} while (playAgain.equalsIgnoreCase("Y"));
		
		//Print game results
		System.out.println("You won " + numberOfWins +
			" out of " + numberOfFlips + " games");
		System.out.println("That's " + 
			(((double) numberOfWins / numberOfFlips) * 100) + "%!");	
	
	}

}