import java.util.Scanner;

public class GrammarFun
{

	public static void main (String[] args)
	{
		Scanner in = new Scanner (System.in);
		
		String userSentence = ""; //This is the original sentence
		String correctedSentence = ""; //Sentence with grammatical corrections
		
		char ch = ' '; //Temp character holder
		
		//Get sentence from user
		System.out.println("Please enter a sentence");
		userSentence = in.nextLine();
		
		//Check sentence, correct any erros, and allow user to enter again
		do
		{
			//Get the first character and make it upper case
			ch = userSentence.charAt(0);
			ch = Character.toUpperCase(ch);
			
			correctedSentence = Character.toString(ch);
			
			//Copy in the rest of the sentence
			correctedSentence = correctedSentence + userSentence.substring(1);

			//Check to make sure the last character is a punctuation character
			ch = correctedSentence.charAt(userSentence.length()-1);
			
			if (ch != '.' && ch != '?' && ch != '!')
			{
				correctedSentence = correctedSentence + ".";
			}
			
			//Print corrected sentence
			System.out.println("Corrected Sentence: " + correctedSentence);
		
			//Allow user to quit or enter another sentence to be corrected
			System.out.println("Enter another sentence (or press Q to quit):");
			userSentence = in.nextLine();
		
		} while (!userSentence.equalsIgnoreCase("Q"));
		
	}

}