import java.util.ArrayList;

public class ArrayListFun
{

	public static void main (String[] args)
	{
	
		ArrayList<String> bands = new ArrayList<String>();
		
		bands.add("The Beatles");
		bands.add("Led Zeppelin");
		bands.add("The Eagles");
		bands.add("Creedence Clearwater Revival");
		bands.add("Queen");
		
		System.out.println(bands);
		
		bands.remove(3);
		
		System.out.println(bands);
		
		System.out.println(bands);
		
		if (bands.indexOf("The Beatles") != 0)
		{
			System.out.println("You're crazy!");
		}
	
	}

}