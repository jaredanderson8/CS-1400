import java.util.Scanner;

public class IfFun
{

	public static void main (String[] args)
	{
		Scanner in = new Scanner (System.in);
		
		int age = 0;
		
		System.out.println("How old are you?");
		age = in.nextInt();
		
		if (age == 25)
		{
			System.out.println("Love that age!");
			System.out.println("I was 25 once!");
		}
	
	}

}