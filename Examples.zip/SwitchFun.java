import java.util.*;

public class SwitchFun
{

	public static void main (String[] args)
	{
	
		Scanner in = new Scanner (System.in);
		
		int age = 0;
		
		//Get the age from the user
		System.out.println("Please enter your age");
		age = in.nextInt();
	
		//Print a comment based on the age
		switch (age)
		{	
			case 16:
				System.out.println("Congratulations!  You can drive!");
				break;
				
			case 21:
				System.out.println("Congratulations!  You can gamble!");
				break;
				
			case 26:
				System.out.println("Congratuations!  You can rent a car!");
				break;
				
			default:
				System.out.println("Wow... Boring age.");
		
		}
	
	}

}