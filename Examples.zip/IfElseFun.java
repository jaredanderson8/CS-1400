import java.util.Scanner;

public class IfElseFun
{

	public static void main (String[] args)
	{
		Scanner in = new Scanner (System.in);
		
		int age = 0;
		
		System.out.println("How old are you?");
		age = in.nextInt();
		
		if (age >= 40)
		{
			System.out.println("You're over the hill!");
		}
		else
		{
			System.out.println("Working your way up the hill!");
		}
	
	
	}

}