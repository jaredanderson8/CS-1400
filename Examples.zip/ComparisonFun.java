public class ComparisonFun
{

	public static void main (String[] args)
	{
	
		String text = "Word";
		
		if (!text.equals("Word"))
		{
			System.out.println("Yes");
		}
		else
		{
			System.out.println("No");
		}
	
	}

}