import java.util.Scanner;

public class Account
{

	public static void main (String[] args)
	{
		Scanner in = new Scanner (System.in);
		
		Calculators c = new Calculators();
		
		double balance = 0.0; //Account balance
		double compoundedBalance = 0.0;
		double earned = 0.0;
		
		//Get balance from user
		System.out.println("What amount is in the account?");
		balance = in.nextDouble();
		
		compoundedBalance = c.compoundInterest(balance, in);
		
		earned = compoundedBalance - balance;
		
		System.out.printf("You earned %.2f in interest.\n", earned);
	}

}