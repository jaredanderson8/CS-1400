/***************************************************
* ReadabilityFun.java
* Spencer Hilton
*
* This class helps us learn about readability
***************************************************/

public class ReadabilityFun
{

	public static void main (String[] args)
	{
		//Print some stuff
		System.out.println("This is some text");
		System.out.println("This is some more text");
	
	} //end main

} //end class ReadabilityFun
