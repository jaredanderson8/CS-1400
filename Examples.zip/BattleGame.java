public class BattleGame
{

	public static void main (String[] args)
	{
		Sniper s1 = new Sniper ();
		
		s1.setEnergy(75);
		
		System.out.println(s1.getEnergy());
	}

}