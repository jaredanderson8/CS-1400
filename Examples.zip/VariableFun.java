public class VariableFun
{

	public static void main (String[] args)
	{
		int age = 25;
		
		System.out.println("I am " + age + " years old.");
	
	}

}