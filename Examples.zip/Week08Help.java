import java.util.*;

public class Week08Help
{

   public static void main (String[] args)
   {
   
      Scanner in = new Scanner (System.in);
      
      int numChampionshipsCubs = 0;
      boolean hasError = false;
      
      do
      {
         try
         {
            hasError = false;
         
            System.out.println("How many championships do the Cubs have?");
            numChampionshipsCubs = in.nextInt();
            
            
         }
         catch (InputMismatchException e)
         {
            //Flush the buffer
            in.nextLine();
         
            System.out.println("Bad Input.  Retry.");
            
            hasError = true;
         }
      } while (hasError);
   
      
   
   }

}