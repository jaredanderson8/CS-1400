import java.util.Scanner;

public class StringFun
{

	public static void main (String[] args)
	{
		int firstSpace = 0;
		int secondSpace = 0;
	
		String sentence = "It's the final countdown!";
		String secondWord = "";
		
		sentence = sentence.trim();
		
		firstSpace = sentence.indexOf(' ');
		secondSpace = sentence.indexOf(' ', firstSpace+1);
		
		System.out.println(firstSpace);
		System.out.println(secondSpace);
		
		secondWord = sentence.substring((firstSpace+1),secondSpace);
		
		secondWord = secondWord.toUpperCase();
		
		System.out.println("The second word is \"" + secondWord + "\".");
	
	}

}