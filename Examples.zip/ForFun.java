public class ForFun
{

	public static void main (String[] args)
	{
		
	
		
		for (int i = 1; i <= numSquares; i++)
		{		
			System.out.println(i + " squared is " + (i*i));
		}
		
	}

}