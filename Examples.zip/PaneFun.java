import javax.swing.JOptionPane;

public class PaneFun
{

	public static void main (String[] args)
	{
		String favTeam = "";
		int selection = 0;
	
		//Show message box
		JOptionPane.showMessageDialog(null, "Hi\nHow are you?");
		
		//Show input box
		favTeam = JOptionPane.showInputDialog(null, "What is your favorite team?");
	
		JOptionPane.showMessageDialog(null, favTeam + " is a good team");
		
		//Show confirm box
		selection = JOptionPane.showConfirmDialog(null, "Best videos ever?");
		
		if (selection == JOptionPane.NO_OPTION)
		{
			JOptionPane.showMessageDialog(null, "Boo");
		}
		if (selection == JOptionPane.YES_OPTION)
		{
			JOptionPane.showMessageDialog(null, "You're my new best friend");
		}
	}

}