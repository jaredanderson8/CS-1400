public class CharacterFun
{

	public static void main (String[] args)
	{
	
		char ch = 'a';
		
		if (Character.isDigit(ch))
		{
			System.out.println("Yes, this is a number.");
		}
		else
		{
			System.out.println("No, this isn't a number.");
		}
	
	}

}