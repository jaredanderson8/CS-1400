import java.util.Scanner;

public class InputFun
{

	public static void main (String[] args)
	{
	
		Scanner in = new Scanner (System.in);
		
		String name = "";
		double weight = 0.0;
		int age = 0;
		
		//Get user name to print greeting
		System.out.println("Please enter your name");
		name = in.next();
		
		//Print greeting
		System.out.println("Hello, " + name);
		
		//Check the weight
		System.out.println("How much do you weigh?");
		weight = in.nextDouble();
		
		System.out.println("Weight: " + weight);
		
		System.out.println("How old are you?");
		age = in.nextInt();
		
		System.out.println("Age: " + age);
	
	}

}