import java.util.Random;

public class OneDie
{

   public static void main (String[] args)
   {
      Random r = new Random();
   
      int[] tally = new int[7];
      
      int roll = 0;
      int numRolls = 1000;
      int numAsterisks = 0;
      
      //Simulate the roll of the die for 100 times
      for (int i = 0; i < numRolls; i++)
      {
         //"Roll" the die
         roll = r.nextInt(6)+1;
         
         tally[roll]++;
         
      } //end for
      
      //Print results
      for (int i = 1; i < tally.length; i++)
      {
         numAsterisks = 100 * tally[i] / numRolls;
      
         System.out.println(i + ": " + numAsterisks);
      }
   
   }

}