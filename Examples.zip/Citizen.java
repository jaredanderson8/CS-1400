public class Citizen
{

	String SSN = "";

	public Citizen (String s)
	{
		this.SSN = s;	
	}

}