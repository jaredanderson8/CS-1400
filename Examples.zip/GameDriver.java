public class GameDriver
{
	public static void main (String[] args)
	{
		Compatibility c = new Compatibility();
	}
}