import java.util.Scanner;
import java.util.Random;

public class RockPaperScissors
{

	public static void main (String[] args)
	{
		Scanner in = new Scanner(System.in);
		Random r = new Random();
	
		String userChoice = "";
		String cpuChoice = "";
		int cpuDraw = 0;
		int userWins = 0;
		int cpuWins = 0;
		int numGames = 0;
		
		System.out.println("How many games would you like to play?");
		numGames = in.nextInt();
		
		for (int i = 1; i <= numGames; i++)
		{
			System.out.println("Rock?  Paper? or Scissors?");
			userChoice = in.nextLine();
			
			//Check for errors here
			
			
			//Computer choice
			cpuDraw = r.nextInt(3);
			
			if (cpuDraw == 0)
			{
				cpuChoice = "Rock";
			}
			if (cpuDraw == 1)
			{
				cpuChoice = "Paper";
			}
			if (cpuDraw == 2)
			{
				cpuChoice = "Scissors";
			}
			
			//Decide outcome
			if (userChoice.equalsIgnoreCase(cpuChoice))
			{
				System.out.println("It's a tie!");
				numGames++;
			}
			if (userChoice.equalsIgnoreCase("Rock") &&
				cpuChoice.equalsIgnoreCase("Paper"))
			{
				System.out.println("Computer wins!");
				cpuWins++;
			}
			if (userChoice.equalsIgnoreCase("Rock") &&
				cpuChoice.equalsIgnoreCase("Scissors"))
			{
				System.out.println("User wins!");
				userWins++;
			}
			
		}
		
		if (userWins > cpuWins)
		{
			System.out.println("User won!");
		}
	
	}

}