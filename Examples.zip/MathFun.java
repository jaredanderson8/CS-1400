public class MathFun
{

	public static void main (String[] args)
	{
	
		// "%" = Modulus
	
		int a = 1;

		a *= 5;
		
		System.out.println(a);
	
	}

}