public class BaseSoldier
{

	private int energy = 100;
	private int x = 0;
	private int y = 0;
	
	public void setEnergy (int e)
	{
		this.energy = e;
	}
	
	public int getEnergy ()
	{
		return this.energy;
	}

}