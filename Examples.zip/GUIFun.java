import javax.swing.*;
import java.awt.*;

public class GUIFun
{

	public static void main (String[] args)
	{
		Home h = new Home();
		
	} //end main

} //end class