public class AnotherJavaClass {

	public void printSomething () {
	
		System.out.println("Hello, world");
	
	}

}