public class VariableIdentifiersFun
{

	public static void main (String[] args)
	{
		//Variable names --> Letters, numbers, and $ and _
		//Variable name cannot start with a number

		int buildingHeight;
	
	}

}