import java.io.PrintWriter;
import java.io.FileNotFoundException;

public class FileOutFun
{

	public static void main (String[] args)
	{
		try
		{
			PrintWriter fileOut = new PrintWriter ("C:\\Examples\\Ouput.txt");
			
			fileOut.println("Just printed some text to a file.");
			fileOut.println("Oh, wait -- Here's some more.");
			
			fileOut.close();
		}
		catch (FileNotFoundException e)
		{
			System.out.println("Sorry, not a valid file.");
		}
	
	}

}