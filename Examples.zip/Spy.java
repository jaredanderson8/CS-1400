public class Spy
{

	public static void main (String[] args)
	{
	
		Citizen c1 = new Citizen("111-222-3333");
	
	}

}