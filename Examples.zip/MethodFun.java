import java.util.Scanner;

public class MethodFun
{

	public static void main (String[] args)
	{
		Scanner in = new Scanner (System.in);
		
		int number = 0;
		int squaredNumber = 0;
		
		System.out.println("Which number would you like squared?");
		number = in.nextInt();
		
		System.out.println("The result is " + square(number));
	
	}
	
	public static int square (int number)
	{
		int result = 0;
		
		result = number * number;
		
		return result;
	}

}