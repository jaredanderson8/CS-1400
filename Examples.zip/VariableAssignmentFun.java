public class VariableAssignmentFun 
{

	public static void main (String[] args)
	{
	
		double buildingHeight = 0;
		
		buildingHeight = (double) 150;
		
		System.out.println(buildingHeight);
	
	}

}