public class Sniper extends BaseSoldier
{
	private int range = 700;
	
	public void setEnergy (int e)
	{
		System.out.println("Hey, you just set my energy");
	}
}