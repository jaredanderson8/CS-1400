import java.util.Scanner;

public class Calculators
{

	public double compoundInterest (double principal, Scanner in)
	{
	
		double interestRate = 0.0; //Rate, represented as a decimal
		int term = 0; //Term of the interest in years
		
		double updatedBalance = 0.0; //Calculated balance
		
		//Get more info from the user
		System.out.println("What is the interest rate?");
		interestRate = in.nextDouble();
		
		System.out.println("What is the term (in years)?");
		term = in.nextInt();
		
		//Compound the interest for the number of terms
		updatedBalance = principal;
		
		for (int i = 1; i <= term; i++)
		{
			updatedBalance = updatedBalance * (1 + interestRate);
		}
		
		return updatedBalance;
	
	}

}