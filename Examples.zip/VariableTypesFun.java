public class VariableTypesFun
{

	public static void main (String[] args)
	{
	
		//int - 32 bit - +/- ~2 Billion
		//long - 64 bit - REALLY big WHOLE numbers
		
		//float - 32 bit
		//double - 64 bit - Really big OR really small floating point numbers
		
		//byte - 8 bit - -128 - 127
		
		//boolean - 8 bit - True/False
		
		//char - 8 bit - ASCII Charcter
		
		String sentence = "This is a sentence";
		
		System.out.println(sentence);
	
	}

}