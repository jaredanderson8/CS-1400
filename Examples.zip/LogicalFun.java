import java.util.Scanner;

public class LogicalFun
{

	public static void main (String[] args)
	{
		// && = AND
		// || = OR
		// ! = NOT
		
		Scanner in = new Scanner (System.in);
		
		String name = "";
		int age = 0;
		
		//Ask user to enter name & age
		System.out.println("Please enter your name");
		name = in.nextLine();
		
		System.out.println("How old are you?");
		age = in.nextInt();
		
		//Decide whether this person is dateable
		if (age < 40 || name.equals("Brad Pitt") || name.equals("Tom Cruise"))
		{
			System.out.println("I will date you");
		}
		else
		{
			System.out.println("Sorry.  You're out of luck");
		}
	
	}

}