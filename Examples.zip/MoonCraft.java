public class MoonCraft
{

	public static void main (String[] args)
	{
	
		Sailor s1 = new Sailor();
		Sailor s2 = new Sailor();
		
		s1.hit(10);
		
		System.out.println(s1.getEnergy());
		System.out.println(s2.getEnergy());
	
	}

}