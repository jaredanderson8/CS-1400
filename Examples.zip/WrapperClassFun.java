import java.util.Scanner;

public class WrapperClassFun
{

	public static void main (String[] args)
	{
	
		Scanner in = new Scanner (System.in);
		
		String input = "";
		int adultAge = 0;
		String output = "";
		
		System.out.println("Please enter the year you were born");
		input = in.nextLine();
		
		adultAge = (int) Double.parseDouble(input) + 18;
		
		output = Integer.toString(adultAge);
		
		System.out.println(output + 5);
	
	}

}